package com.cms.authorizationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmsApiGatewayAuthorizationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
